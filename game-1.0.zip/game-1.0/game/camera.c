#include "camera.h"

const vec3 UP = {0, 1, 0};
void printCamera(Camera *c){
  printf("Pos: %f %f %f\n", c->pos[0], c->pos[1], c->pos[2]);
}

void camera_update(Camera *c)
{
  mat4x4_identity(c->m);
  vec3 center = {c->pos[0] + cosf(c->rx), c->pos[1] + sinf(c->ry), c->pos[2] + sinf(c->rx)};
  mat4x4_look_at(c->m, c->pos, center, UP);
}

void camera_move(Camera *c, float const dp)
{
  c->pos[0] += cosf(c->rx) * dp; //x
  c->pos[2] += sinf(c->rx) * dp; //z
  camera_update(c);
  //camera_load(c);
}

void camera_rotate(Camera *c, float const dx, float const dy)
{
  c->rx += dx;
  c->ry += dy;
  if(c->ry > MAX_Y_ANGLE)
    c->ry = MAX_Y_ANGLE;
  else if(c->ry < MIN_Y_ANGLE)
    c->ry = MIN_Y_ANGLE;

  camera_update(c);
}
