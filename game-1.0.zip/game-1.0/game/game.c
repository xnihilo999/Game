#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "linmath.h"

#define GLAD_GL_IMPLEMENTATION
#include <glad/gl.h>

#define GLFW_INCLUDE_NONE
#include <GLFW/glfw3.h>



void cube(float x, float y, float z)
{
  glShadeModel(GL_FLAT);


  int a[8][5] = {
    {0, 0, 1, 0, 0},
    {1, 0, 1, 1, 0},
    {1, 1, 1, 1, 1},
    {0, 1, 1, 0, 1},

    {0, 0, 0, 0, 0},
    {0, 1, 0, 0, 1},
    {1, 1, 0, 1, 1},
    {1, 0, 0, 1, 0},
  };
  int n[5] = {0, 0, 1, 0, 0};
  int *v;
  int i,j;
  glBegin(GL_QUADS);
  for(i=0;i<3;i++){
    v = n + i;
    glNormal3f(v[0], v[1], v[2]);
    for(j=0;j<4;j++){
      v = a[j] + i;
      glVertex3f(x + v[0], y + v[1], z + v[2]);
    }
    v = n + i;
    glNormal3f(-v[0], -v[1], -v[2]);
    for(;j<8;j++){
      v = a[j] + i;
      glVertex3f(x + v[0], y + v[1], z + v[2]);
    }

  }
  glEnd();
}

#include "camera.h"
Camera camera;
void camera_load(Camera *c)
{
  glMatrixMode( GL_MODELVIEW);
  glLoadMatrixf((const GLfloat *) c->m);
  glMatrixMode( GL_PROJECTION );
  glLoadMatrixf((const GLfloat *) c->p);
}

#define GRIDX 16
#define GRIDY 6
#define GRIDZ 16
int grid[GRIDX][GRIDY][GRIDZ];

void update_grid(void);
void init_grid(void)
{
  int x,y,z;
  for(x=0;x<GRIDX;x++)
    for(y=0;y<GRIDY;y++)
      for(z=0;z<GRIDZ;z++)
        grid[x][y][z] = (y == 0);
}

static GLint cube1;

static void draw(void)
{
  glClearColor(0.3f, 0.7f, 1.0f, 1.0); //sky
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

  glMatrixMode(GL_MODELVIEW);
  glPushMatrix();
    glCallList(cube1);
  glPopMatrix();
}


#define STEP 0.2f
#define MAX_PLACE_DIST 10
int find_block(int g[3], int nearest_filled);

//pick: find block. backtrack, place.
//remove: find block, remove it.
//highlight: find block, color it.

int place(void)
{
  int data[3], found;
  if((found = find_block(data, 0)) != 0) //backtrack from nearest filled
    grid[data[0]][data[1]][data[2]] = 1; //fill it
  return found;
}

int pick(void)
{
  int data[3], found;
  if((found = find_block(data, 1)) != 0) //yes nearest filled
    grid[data[0]][data[1]][data[2]] = 0; //remove it
  return found;
}


int prev_highlight[3] = {0, 0, 0};
int highlight(void)
{
  int data[3], found, *prev;
  prev = &(grid[prev_highlight[0]][prev_highlight[1]][prev_highlight[2]]);
  if(*prev >= 2) //remove previous if it is highlighted.
    *prev -= 2;
  if((found = find_block(data, 1)) != 0){ //yes nearest filled
    prev = &(grid[data[0]][data[1]][data[2]]);
    if(*prev < 2) //highlight if not already
      *prev += 2;
    prev_highlight[0] = data[0]; prev_highlight[1] = data[1]; prev_highlight[2] = data[2];
  }
  update_grid(); //make some conditional here.
  return found;
}


int find_block(int g[3], int nearest_filled)
{
  float x,y,z,dx,dy,dz,t;
  int gx,gy,gz,found;
  x = camera.pos[0]; y = camera.pos[1]; z = camera.pos[2];
  dx = cosf(camera.rx) * cosf(camera.ry) * STEP;
  dy = sinf(camera.ry) * STEP;
  dz = sinf(camera.rx) * cosf(camera.ry) * STEP;
  t = 0.f; //dist traveled
  found = 0;
  while(t < MAX_PLACE_DIST){
    x += dx; y += dy; z += dz;
    gx = (int)x; gy = (int)y; gz = (int)z;
    t += STEP;
    if(gx < 0 || gx >= GRIDX || gy < 0 || gy >= GRIDY || gz < 0 || gz >= GRIDY)
      continue;
    if(grid[gx][gy][gz] != 0){
      if(!nearest_filled){
        x -= dx; y -= dy; z -= dz; //back track to place where just was nothing
      }
      g[0] = (int)x; g[1] = (int)y; g[2] = (int)z;
      return 1;
    }
  }
  return 0;
}


static double mouseX, mouseY, pmouseX, pmouseY;
static void cursor_position_callback(GLFWwindow* window, double xpos, double ypos)
{
  const float s = 0.006f;
  pmouseX = mouseX;
  pmouseY = mouseY;
  mouseX = xpos;
  mouseY = ypos;
  float dx = mouseX - pmouseX;
  float dy = mouseY - pmouseY;
  camera_rotate(&camera, (float)dx * s, -(float)dy * s);
  camera_load(&camera);
  highlight();
}

static GLfloat colors[4][4] = {
  {0.f, 1.f, 0.f, 1.f}, //green
  {0.5f, 0.5f, 0.5f, 1.f}, //grey
  {1.f, 1.f, 0.f, 1.f}, //yellow
  {1.f, 0.f, 0.f, 1.f} //red
};
void update_grid(void)
{
  cube1 = glGenLists(1);
  glNewList(cube1, GL_COMPILE);
  int x,y,z;
  for(x=0;x<GRIDX;x++)
    for(y=0;y<GRIDY;y++)
      for(z=0;z<GRIDZ;z++)
        if(grid[x][y][z] != 0){
          glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, colors[grid[x][y][z]]);
          cube(x, y, z);
        }

  glEndList();
}

int cursor_visible = 0;
int movement[2] = {0, 0}; //F, B not moving
/* change view angle, exit upon ESC */
void key( GLFWwindow* window, int k, int s, int action, int mods )
{
  //if( action != GLFW_PRESS ) return;
  //float r = 0.2f;
  float dx = 0.30f; //make framerate independent
  switch (k) {
    case GLFW_KEY_ESCAPE:
      if(action != GLFW_PRESS)break;
      glfwSetInputMode(window, GLFW_CURSOR, cursor_visible = !cursor_visible ? GLFW_CURSOR_NORMAL : GLFW_CURSOR_DISABLED);
      break;
    case GLFW_KEY_SPACE:
      camera.pos[1] += 1; //jump
      camera_update(&camera);
      camera_load(&camera);
      break;
    case GLFW_KEY_X:
      camera.pos[1] -= 1; //jump down
      camera_update(&camera);
      camera_load(&camera);
      break;
    case GLFW_KEY_W: //forward
      if(movement[0] == 0){ //not moving then moving
        if(action != GLFW_RELEASE)
          movement[0] = 1;
      }
      else if(action == GLFW_RELEASE) //stops moving
        movement[0] = 0;
      if(movement[0] - movement[1] != 0){
        camera_move(&camera, (movement[0] - movement[1]) * dx);
        camera_load(&camera);
      }
      break;
    case GLFW_KEY_S: //back
      if(movement[1] == 0){ //not moving then moving
        if(action != GLFW_RELEASE)
          movement[1] = 1;
      }
      else if(action == GLFW_RELEASE) //stops moving
        movement[1] = 0;
      if(movement[0] - movement[1] != 0){
        camera_move(&camera, (movement[0] - movement[1]) * dx);
        camera_load(&camera);
      }
      break;
    case GLFW_KEY_Q:
      if(action != GLFW_PRESS)break;
      place();
        update_grid();
      break;
    case GLFW_KEY_E:
      if(action != GLFW_PRESS)break;
      pick();
        update_grid();
      break;
  }
}



/* new window size */
void reshape( GLFWwindow* window, int width, int height )
{
  GLfloat h = (GLfloat) height / (GLfloat) width;
  GLfloat xmax, znear, zfar;
  znear = 0.1f;
  zfar  = 30.0f;
  xmax  = znear * 0.5f;
  glViewport( 0, 0, (GLint) width, (GLint) height);

  mat4x4_identity(camera.p);
  mat4x4_frustum(camera.p, -xmax, xmax, -xmax*h, xmax*h, znear, zfar );//it's a square frustum!!!

  camera.pos[0] = 0; camera.pos[1] = 2; camera.pos[2] = 0;
  camera.rx = camera.ry = 0;

  camera_update(&camera);
  camera_load(&camera);
}



/* program & OpenGL initialization */
static void init(void)
{
  static GLfloat pos[4] = {0.f, 0.f, 0.f, 1.f};

  glLightfv(GL_LIGHT0, GL_POSITION, pos);
  glEnable(GL_CULL_FACE);
  glEnable(GL_LIGHTING);
  glEnable(GL_LIGHT0);
  glEnable(GL_DEPTH_TEST);

  init_grid(); //set some initial values
  update_grid(); //load cubes into GL

  glEnable(GL_NORMALIZE);
}


/* program entry */
int main(int argc, char *argv[])
{
    GLFWwindow* window;
    int width, height;

    if( !glfwInit() )
    {
        fprintf( stderr, "Failed to initialize GLFW\n" );
        exit( EXIT_FAILURE );
    }

    glfwWindowHint(GLFW_DEPTH_BITS, 16);
    glfwWindowHint(GLFW_TRANSPARENT_FRAMEBUFFER, GLFW_TRUE);

    window = glfwCreateWindow( 1200, 840, "Shapes", NULL, NULL );
    if (!window)
    {
        fprintf( stderr, "Failed to open GLFW window\n" );
        glfwTerminate();
        exit( EXIT_FAILURE );
    }

    // Set callback functions
    glfwSetFramebufferSizeCallback(window, reshape);
    glfwSetKeyCallback(window, key);
    glfwSetCursorPosCallback(window, cursor_position_callback);
    glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);
    //cursor_position_callback(window );

    glfwMakeContextCurrent(window);
    gladLoadGL(glfwGetProcAddress);
    glfwSwapInterval( 1 );

    glfwGetFramebufferSize(window, &width, &height);
    reshape(window, width, height);

    // Parse command-line options
    init();

    // Main loop
    while( !glfwWindowShouldClose(window) )
    {
        draw();

        // Swap buffers
        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    // Terminate GLFW
    glfwTerminate();

    // Exit program
    exit( EXIT_SUCCESS );
}
