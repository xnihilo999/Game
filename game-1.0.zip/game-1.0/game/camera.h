#ifndef CAMERA_H
#define CAMERA_H

#include <math.h>
#include <stdio.h>
#include "linmath.h"



#define MAX_Y_ANGLE M_PI_2 * 0.99
#define MIN_Y_ANGLE -M_PI_2 * 0.99

typedef struct {
  mat4x4 p;
  mat4x4 m;
  vec3 pos;
  //vec3 center;
  float rx, ry; //rotation x, y
  //rz
} Camera;

void printCamera(Camera *c);
void camera_update(Camera *c);
void camera_move(Camera *c, float const dp);
void camera_rotate(Camera *c, float const dx, float const dy);


#endif
